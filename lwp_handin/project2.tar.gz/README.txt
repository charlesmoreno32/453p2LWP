Matthew Bosio and Charles Moreno

You can compile it by running make nums, make snakes or make hungry
You should then be able to run /nums, /snakes and /hungry

We believe that we have the program fully working

We weren't sure what was needed to have it running properly because
there are so many files, so we decided to turn in everything in the
folder we worked in